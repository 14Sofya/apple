import pygame
from random import randint


game_score = 0
life_score = 3

class Apple(pygame.sprite.Sprite):
    def __init__(self, x, speed, surf, score, type_apple, group):
        pygame.sprite.Sprite.__init__(self)
        self.image = surf
        self.rect = self.image.get_rect(center=(x, 0))
        self.speed = speed
        self.score = score
        self.type_apple = type_apple
        self.flag = 0
        self.add(group)


    def update(self, *args):
        global game_score
        if self.rect.y < args[0] - 20:
            self.rect.y += self.speed
            if self.rect.y > 529:
                self.flag = 1
        else:
            self.kill()

def intro():
    intro = True
    smallfont = pygame.font.SysFont('Bauhaus 93', 70)
    while intro == True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.KEYDOWN:
                intro = False
                main()
        pygame.display.set_caption('apples')
        size = width, height = 600, 550
        screen = pygame.display.set_mode(size)
        back = pygame.image.load("img/appletreepixel2.png")
        back = pygame.transform.scale(back, (width, height))
        screen.blit(back, (0, 0))
        text = smallfont.render("Start", 1, (255, 255, 255))
        text_rect = text.get_rect(center=(width / 2, height / 2))
        screen.blit(text, text_rect)
        pygame.display.update()


def main():
    global life_score
    global game_score

    pygame.time.set_timer(pygame.USEREVENT, 860)

    pygame.display.set_caption('apples')
    size = width, height = 600, 550
    screen = pygame.display.set_mode(size)

    apples = pygame.sprite.Group()

    background = pygame.image.load("img/appletree2pixel2.png")

    clock = pygame.time.Clock()
    FPS = 60

    font = pygame.font.SysFont('Cascadia Mono SemiBold', 40)

    basket = pygame.image.load('img/img3.png').convert_alpha()
    basket_rect = basket.get_rect(centerx=width // 2, bottom=height - 5)

    apples_data = ({'path': 'red_apple.png', 'score': 5},
                  {'path': 'gold_apple2.png', 'score': 10},
                  {'path': 'bad_apple.png', 'score': -100})
    apples_surf = [pygame.image.load('img/'+data['path']).convert_alpha() for data in apples_data]

    def createApple(group):
        indx = randint(0, len(apples_surf) - 1)
        x = randint(20, width - 20)
        speed = randint(4, 9)

        return Apple(x, speed, apples_surf[indx], apples_data[indx]['score'], apples_data[indx]['path'], group)

    def collideApples():
        global game_score
        global life_score
        for apple in apples:

            if basket_rect.collidepoint(apple.rect.center):
                type_apple = apple.type_apple
                if type_apple == 'bad_apple.png':
                    life_score -= 1
                game_score += apple.score
                apple.kill()
            elif apple.flag == 1:
                  type_apple = apple.type_apple
                  if type_apple != 'bad_apple.png':
                      game_score -= apple.score


    createApple(apples)
    speed = 15
    level = 1

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.USEREVENT:
                createApple(apples)
        if life_score != 0 and - 300 < game_score < 500:

            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                basket_rect.x -= speed
                if basket_rect.x < 0:
                    basket_rect.x = 0
            elif keys[pygame.K_RIGHT]:
                basket_rect.x += speed
                if basket_rect.x > width - basket_rect.width:
                    basket_rect.x = width - basket_rect.width

            if game_score >= 200 and level == 1:
                speed = 10
                background = pygame.image.load('img/level2pixel.png')
                life_score = 3
                level = 2

            if game_score >= 400 and level == 2:
                speed = 5
                background = pygame.image.load('img/level3pixel.png')
                life_score = 3
                level = 3

            screen.blit(background, (0, 0))
            text = font.render("Счет: {}".format(game_score), 1, (255, 255, 255))
            text_2 = font.render("  X {}".format(life_score), 1, (255, 255, 255))
            text_rect = text.get_rect(center=(width / 2, 15))
            text_rect_2 = text_2.get_rect(center=(width / 2 + 17.5, 40))
            heart = pygame.image.load('img/heart.png')
            heart = pygame.transform.scale(heart, (30, 30))
            heart_rect = heart.get_rect(center=(width/2 - 18, 40))
            screen.blit(text, text_rect)
            screen.blit(text_2, text_rect_2)
            screen.blit(heart, heart_rect)
            apples.draw(screen)
            screen.blit(basket, basket_rect)
            pygame.display.update()

            clock.tick(FPS)

            apples.update(height)
            collideApples()

        elif game_score >= 500:
            smallfont = pygame.font.SysFont('Bauhaus 93', 60)
            font = pygame.font.SysFont('Cascadia Mono SemiBold', 40)
            final = pygame.image.load('img/finalpixel.png')
            screen.blit(final, (0, 0))
            text = smallfont.render("Game Over", 1, 'white')
            text_rect = text.get_rect(center=(width / 2, height / 2 - 20))
            text_2 = font.render('Вы собрали все яблоки!', 1, 'white')
            text_rect_2 = text_2.get_rect(center=(width / 2, height / 2 + 20))
            screen.blit(text, text_rect)
            screen.blit(text_2, text_rect_2)
            pygame.display.update()

        elif life_score == 0 or game_score == -300:
            smallfont = pygame.font.SysFont('Bauhaus 93', 60)
            final = pygame.image.load('img/finalpixel_bad.png')
            final_rect = final.get_rect(center=(width / 2, height / 2))
            screen.blit(final, (0, 0))
            text = smallfont.render("Game Over", 1, 'white')
            text_rect = text.get_rect(center=(width / 2, height / 2))
            screen.blit(text, text_rect)
            pygame.display.update()

    pygame.quit()


if __name__ == '__main__':
    pygame.init()
    intro()